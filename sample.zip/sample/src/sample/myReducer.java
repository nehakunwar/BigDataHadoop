package sample;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer extends Reducer<Text,IntWritable,Text,IntWritable> {
	public void reduce(Text inpk,Iterable<IntWritable> inpv,Context c) throws IOException, InterruptedException{
		int count=0;
		for(@SuppressWarnings("unused") IntWritable x:inpv)
		{
			count++;
		}
		c.write(new Text("Total number of"+inpk+"is:"),new IntWritable(count));
	}

}
