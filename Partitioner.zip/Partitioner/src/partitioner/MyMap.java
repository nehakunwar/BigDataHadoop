package partitioner;

public class MyMap {

}
