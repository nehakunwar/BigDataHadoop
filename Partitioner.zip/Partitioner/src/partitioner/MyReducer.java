package partitioner;

public class MyReducer {

}
