import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer extends Reducer<Text, Text, Text, IntWritable> {
	public void reduce(Text inpK, Iterable<Text> inpV, Context c) throws IOException, InterruptedException{
		int max=0,value=0;
		String module=" ";
		for(Text each: inpV){
			String [] eachval= each.toString().split(":");
			value=Integer.parseInt(eachval[1]);
			if(max<value)
				max=value;
			module=eachval[0];
		}
		c.write(new Text(module), new IntWritable(max));
	}
	

}
