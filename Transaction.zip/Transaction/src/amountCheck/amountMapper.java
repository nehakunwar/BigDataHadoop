package amountCheck;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
//import org.apache.hadoop.io.IntWritable;
//import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class amountMapper extends Mapper<LongWritable,Text, Text, DoubleWritable>{
	public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException{
		String value=inpv.toString();
		String eachval[]=value.split(",");
		//double outk=Integer.parseDouble(eachval[3]);
		double outk=Double.parseDouble(eachval[3]);
		if(outk>160)
			c.write(new Text(eachval[2]), new DoubleWritable(outk));
			
		}
			
			
		}
		
	


