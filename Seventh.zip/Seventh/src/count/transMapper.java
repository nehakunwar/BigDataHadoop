package count;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
//import org.apache.hadoop.io.IntWritable;
//import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

public class transMapper extends Mapper<LongWritable,Text, Text, IntWritable>{
	public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException{
		String value=inpv.toString();
		String eachval[]=value.split(" ");
		//double outk=Integer.parseDouble(eachval[3]);
		Text date=new Text(eachval[3]);
		//String dat=date.toString();
		//String val[]=dat.split("-");
		//int dd=Integer.parseInt(val[0]);
		//double num1=Double.parseDouble(eachval[3]);
		IntWritable outk=new IntWritable(1);
		//DoubleWritable outv=new DoubleWritable(num1);
		
	
			c.write(date,outk);
			
		}
	

}
