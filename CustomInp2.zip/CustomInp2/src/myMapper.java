import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<myKey, myValue, Text, Text> {
	
	public void map(myKey inpK, myValue inpV, Context c) throws IOException, InterruptedException{
		
		int amt = inpV.getAmt();
		if(amt>=175 && amt<=200){
			c.write(new Text(inpK.getid()), new Text(Double.toString(inpV.getAmt())));
		}
	}

}
